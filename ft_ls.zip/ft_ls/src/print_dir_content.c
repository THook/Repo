/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_dir_content.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsierra- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/04/12 04:28:50 by nsierra-          #+#    #+#             */
/*   Updated: 2014/04/12 07:38:57 by nsierra-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <errno.h>
#include <dirent.h>
#include <ft_ls.h>
#include <libft.h>

void				add_entry(t_direntries **lst,
							struct dirent *entity, char *file_path)
{
	t_direntries	*new_elem;

	if (*lst == NULL && (new_elem = malloc(sizeof(t_direntries))))
	{
		if (stat(file_path, &new_elem->stat_info) == -1)
			print_error(file_path, 0);
		new_elem->file_path = file_path;
		new_elem->entry = entity;
		new_elem->next = NULL;
		*lst = new_elem;
	}
	else if ((new_elem = malloc(sizeof(t_direntries))))
	{
		if (stat(file_path, &new_elem->stat_info) == -1)
			print_error(file_path, 0);
		new_elem->file_path = file_path;
		new_elem->entry = entity;
		new_elem->next = *lst;
		*lst = new_elem;
	}
}

static t_direntries	*build_direntries_lst(char *path)
{
	DIR				*directory;
	struct dirent	*entity;
	t_direntries	*lst;

	lst = NULL;
	if (!(directory = opendir(path)))
	{
		(void)print_error(path, 0);
		return (NULL);
	}
	while ((entity = readdir(directory)) != NULL)
	{
		add_entry(&lst, entity, path_builder(path, entity->d_name));
	}
	closedir(directory);
	return (lst);
}

void		print_list(t_direntries *lst)
{
	t_direntries *cursor;

	cursor = lst;
	while (cursor != NULL)
	{
		printf("direntity <%s>\n", cursor->entry->d_name);
		cursor = cursor->next;
	}
}

void				print_dir_content(t_pathlst *pathlst, t_opflag *opflag)
{
	t_pathlst		*cursor;
	t_direntries	*direntries;

	(void)opflag;
	cursor = pathlst;
	while (cursor != NULL)
	{
		printf("Dir teste <%s>\n", cursor->path);
		direntries = build_direntries_lst(cursor->path);
		cursor = cursor->next;
	}
	print_list(direntries);
}
