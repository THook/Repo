/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_lst.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsierra- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/04/12 03:22:18 by nsierra-          #+#    #+#             */
/*   Updated: 2014/04/12 04:44:15 by nsierra-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <ft_ls.h>

void	print_lst(t_env *e)
{
	t_pathlst	*cursor;

	cursor = e->pathlst;
	while (cursor != NULL)
	{
		print_dir_content(e->pathlst, &e->opflag);
		cursor = cursor->next;
	}
}
