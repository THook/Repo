/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsierra- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/04/12 01:48:49 by nsierra-          #+#    #+#             */
/*   Updated: 2014/04/12 06:55:43 by nsierra-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_LS_H
# define FT_LS_H
# include <sys/stat.h>

typedef struct			s_options_flags
{
	int					l;
	int					r;
	int					rmaj;
	int					a;
	int					t;
	int					no_option;
}						t_opflag;

typedef struct			s_direntries
{
	char				*file_path;
	struct dirent		*entry;
	struct stat			stat_info;
	struct s_direntries	*next;
}						t_direntries;

typedef struct			s_pathlst
{
	char				*path;
	struct s_pathlst	*next;
}						t_pathlst;

typedef struct			s_env
{
	t_opflag			opflag;
	t_pathlst			*pathlst;
}						t_env;

int						check_input(int ac, char **av, t_env *env);
void					add_path(char *path, t_env *e);
void					print_lst(t_env *e);
int						print_error(char *incriminated_var, int ret);
void					print_dir_content(t_pathlst *pathlst, t_opflag *opflag);
char					*path_builder(char *path, char *file);

#endif
